Chatify portable app

Extract into a new empty directory.
Run: chatify validate app.yaml
Then: chatify run app.yaml

Set these environment variables yourself: OPENAI_API_KEY

Local source documents are included. Review them before sharing.
Keys, accounts, conversations, uploads, caches and saved looks are not included.
Remote sources, fonts and background URLs still require their original services.
